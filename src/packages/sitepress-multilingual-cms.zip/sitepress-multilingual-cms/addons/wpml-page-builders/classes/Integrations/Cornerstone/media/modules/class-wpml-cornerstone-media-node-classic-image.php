<?php

class WPML_Cornerstone_Media_Node_Classic_Image extends WPML_Cornerstone_Media_Node_With_URLs {

	protected function get_keys() {
		return array(
			'src',
		);
	}
}
