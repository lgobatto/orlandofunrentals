<?php

interface IWPML_PB_Media_Update {

	/**
	 * @param WP_Post $post
	 */
	public function translate( $post );
}
